scp -r ../../SciCumulusCore/target/SciCumulusCore-1.8-jar-with-dependencies.jar root@ec2-54-237-170-42.compute-1.amazonaws.com:/root/programs/SciCumulusCore.jar
