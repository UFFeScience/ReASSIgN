java -jar bin/SciCumulusSetup.jar -d SciCumulus.xml
java -jar bin/SciCumulusSetup.jar -i SciCumulus.xml