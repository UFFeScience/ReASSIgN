scp -r ../../SciCumulusCore/target/SciCumulusCore-1.8-jar-with-dependencies.jar root@ec2-54-198-4-92.compute-1.amazonaws.com:/root/programs/SciCumulusCore.jar
