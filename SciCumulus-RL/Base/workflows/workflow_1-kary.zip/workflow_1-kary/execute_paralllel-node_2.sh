java -jar bin/SciCumulusCore.jar SciCumulus.xml 1
